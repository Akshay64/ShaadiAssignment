package screens;

import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class HomeScreen {
	private AndroidDriver driver;

	@AndroidFindBy(id = "com.shaadi.android:id/tvMyShaadi")
	AndroidElement home;

	@AndroidFindBy(xpath = ".//*[contains(@text,'Premium Matches')]")
	AndroidElement premiumMatches;

	@AndroidFindBy(xpath = ".//*[contains(@text,'Premium Matches')]/..//*[contains(@text,'See All')]")
	AndroidElement seeAll_premium_matches;

	@AndroidFindBy(xpath = ".//*[@text='Connect Now']")
	AndroidElement connectNow;

	@AndroidFindBy(id = "com.shaadi.android:id/btnNotSatisfied")
	AndroidElement notNow;

	@AndroidFindBy(xpath = ".//*[contains(@text,'New Matches')]")
	AndroidElement newMatches;

	@AndroidFindBy(xpath = ".//*[contains(@text,'New Matches')]/..//*[contains(@text,'See All')]")
	AndroidElement seeAll_new_matches;

	public HomeScreen(AndroidDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public void verifyPremiumMatches() {
		home.click();
		if (premiumMatches.isDisplayed()) {
			driver.findElementByAndroidUIAutomator(
					"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
							+ "Members who joined recently" + "\").instance(0))");

			/*
			 * driver.findElementByAndroidUIAutomator( "new UiScrollable(" +
			 * "new UiSelector().scrollable(true)).scrollIntoView(" +
			 * "new UiSelector().text(\"" + "Members who joined recently" + "\"));");
			 */

			seeAll_premium_matches.click();

			driver.findElementByAndroidUIAutomator(
					"new UiScrollable(" + "new UiSelector().scrollable(true)).scrollIntoView("
							+ "new UiSelector().text(\"" + "Connect Now" + "\"));");

			connectNow.click();

			driver.navigate().back();
			try {
				if (notNow.isDisplayed()) {
					notNow.click();
					Thread.sleep(3000);
					driver.navigate().back();

				}
			} catch (Exception e) {
				System.out.println("Rate Us dialog not displayed");
			}

		}
	}

	public void verifyNewMatches() {
		if (newMatches.isDisplayed()) {
			/*
			 * driver.findElementByAndroidUIAutomator( "new UiScrollable(" +
			 * "new UiSelector().scrollable(true)).scrollIntoView(" +
			 * "new UiSelector().text(\"" + "Members who visited your Profile" + "\"));");
			 */

			driver.findElementByAndroidUIAutomator(
					"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
							+ "visited your Profile" + "\").instance(0))");

			seeAll_new_matches.click();

			driver.findElementByAndroidUIAutomator(
					"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
							+ "Connect Now" + "\").instance(0))");

			connectNow.click();

			driver.navigate().back();
		}

	}
}
