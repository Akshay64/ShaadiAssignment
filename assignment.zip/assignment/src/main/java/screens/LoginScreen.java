package screens;

import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LoginScreen {

	private AndroidDriver driver;

	@AndroidFindBy(id = "com.shaadi.android:id/btn_morph_login")
	AndroidElement loginOption;

	@AndroidFindBy(id = "com.shaadi.android:id/edt_username")
	AndroidElement username;

	@AndroidFindBy(id = "com.shaadi.android:id/edt_password")
	AndroidElement password;

	@AndroidFindBy(id = "com.shaadi.android:id/btn_login")
	AndroidElement loginBtn;

	@AndroidFindBy(id = "com.android.permissioncontroller:id/permission_allow_foreground_only_button")
	AndroidElement allowBtn;

	@AndroidFindBy(id = "com.shaadi.android:id/textView_upgrade_title")
	AndroidElement upgradeTitle;

	@AndroidFindBy(id = "com.shaadi.android:id/menu_skip")
	AndroidElement skip;
	
	@AndroidFindBy(xpath = ".//*[@text='Home']")
	AndroidElement home;
	

	public LoginScreen(AndroidDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	public void login(String id, String pass) {

		// loginOption.click();

		// username.clear();
		username.sendKeys(id);

		// password.clear();
		password.sendKeys(pass);

		loginBtn.click();
		try {

			if (allowBtn.isDisplayed()) {
				allowBtn.click();
			}

			if (upgradeTitle.isDisplayed()) {
				skip.click();
			} else {
				System.out.println("Upgrade to Premium title is not displayed");
			}
			
			if(home.isDisplayed()) {
				System.out.println("Logged in successfully !");
			}
		}

		catch (Exception e) {
			System.out.println("Upgrade dialog not displayed");
		}
		
	
	}
	
	

}
