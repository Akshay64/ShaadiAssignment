package tests;

import org.testng.annotations.Test;

public class HomeTests extends Setup {
	@Test(priority = 2, description = "Navigate to premium matches and send one connect request")
	public void premiumMatches() {
		home.verifyPremiumMatches();
		home.verifyNewMatches();
	}

	@Test(priority = 3, description = "Navigate to new matches and send one connect request")
	public void newMatches() {
		home.verifyNewMatches();
	}
}
