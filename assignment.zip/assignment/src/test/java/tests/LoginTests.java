package tests;

import org.testng.annotations.Test;

public class LoginTests extends Setup {
  @Test (priority = 1, description = "To verify login funtionality with valid credentials")
  public void loginTest() {
	 login.login("shwetaakshaymahajan@gmail.com", "Shaadi@123");
	 home.verifyPremiumMatches();
	 home.verifyNewMatches();
  }
}
