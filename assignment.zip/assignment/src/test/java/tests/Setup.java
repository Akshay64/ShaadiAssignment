package tests;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import screens.HomeScreen;
import screens.LoginScreen;

public class Setup {
	public static AndroidDriver driver;
	public static LoginScreen login;
	public static HomeScreen home;
  @BeforeSuite
  public void appLaunch() throws MalformedURLException {
	  DesiredCapabilities caps = new DesiredCapabilities();
	  caps.setCapability("platformName", "Android");
	  caps.setCapability("platformVersion", "10.0");
	  caps.setCapability("deviceName", "2da5e06e");
	  caps.setCapability("appPackage", "com.shaadi.android");
	  caps.setCapability("appActivity", "com.shaadi.android.ui.login.NewLoginActivity");
	  caps.setCapability("platform", "Android");
	  caps.setCapability("automationName", "uiautomator2");
	  
	  driver = new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"),caps);
	  driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	  
	  login = new LoginScreen(driver);
	  home = new HomeScreen(driver);
  }
}
